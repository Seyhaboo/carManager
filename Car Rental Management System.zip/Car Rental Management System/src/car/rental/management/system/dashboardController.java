/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package car.rental.management.system;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author User
 */
public class dashboardController implements Initializable{
    
    
        @FXML
    private TextField avallableCars_brand;

    @FXML
    private Button avallableCars_btn;

    @FXML
    private TextField avallableCars_carId;

    @FXML
    private Button avallableCars_clearBtn;

   
    @FXML
    private Button avallableCars_deleteBtn;

    @FXML
    private AnchorPane avallableCars_form;

    @FXML
    private ImageView avallableCars_imageView;

    @FXML
    private Button avallableCars_import;

    @FXML
    private Button avallableCars_insertbtn;

    @FXML
    private TextField avallableCars_model;

    @FXML
    private TextField avallableCars_price;

    @FXML
    private TextField avallableCars_search;

    @FXML
    private ComboBox<?> avallableCars_status;

    @FXML
    private TableView<carData> avallableCars_tableView;
    
    @FXML
    private TableColumn<carData, String> avallableCars_col_brand;

    @FXML
    private TableColumn<carData, String> avallableCars_col_carId;

    @FXML
    private TableColumn<carData, String> avallableCars_col_model;

    @FXML
    private TableColumn<carData, String> avallableCars_col_price;

    @FXML
    private TableColumn<carData, String> avallableCars_col_status;


    @FXML
    private Button avallableCars_updateBtn;

    @FXML
    private Button close;

    @FXML
    private Label home_avallableCars;

    @FXML
    private Button home_btn;

    @FXML
    private LineChart<?, ?> home_customerchart;

    @FXML
    private BarChart<?, ?> home_incomeChart;

    @FXML
    private Label home_totalCustomer;

    @FXML
    private Label home_totalincome;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button minimize;

    @FXML
    private Button rentBtn;

    @FXML
    private Button rentCar_btn;

    @FXML
    private TextField rent_amoumt;

    @FXML
    private Label rent_balance;
    
    
    @FXML
    private AnchorPane home_form;

    @FXML
    private ComboBox<?> rent_brand;

    @FXML
    private ComboBox<?> rent_carId;

    @FXML
    private TextField rent_carfirstName;

    @FXML
    private TextField rent_carlastName;

    @FXML
    private TableColumn<carData, String> rent_col_brand;

    @FXML
    private TableColumn<carData, String> rent_col_carId;

    @FXML
    private TableColumn<carData, String> rent_col_model;

    @FXML
    private TableColumn<carData, String> rent_col_price;

    @FXML
    private TableColumn<carData, String> rent_col_status;

    @FXML
    private DatePicker rent_dateRented;

    @FXML
    private DatePicker rent_dateReturn;

    @FXML
    private AnchorPane rent_form;

    @FXML
    private ComboBox<?> rent_gender;

    @FXML
    private ComboBox<?> rent_model;

    @FXML
    private TableView<carData> rent_tableView;

    @FXML
    private Label rent_total;

    @FXML
    private Label username;
    //DATABASE TOOLS
   private Connection connect;
   private PreparedStatement prepare;
   private ResultSet result;
   private Statement statement;
   
   private Image image;
   
   public void avallableCarAdd(){
     
       String sql = "INSERT INTO car (car_id, brand, model, price, status, image, date) "
               + "VALUES(?,?,?,?,?,?,?)";
       
       connect = database.connectDb();
       try{
           Alert alert;
           if(avallableCars_carId.getText().isEmpty()
                   ||avallableCars_brand.getText().isEmpty()
                   ||avallableCars_model.getText().isEmpty()
                   ||avallableCars_status.getSelectionModel().getSelectedItem()==null
                   ||avallableCars_price.getText().isEmpty()
                   ||getData.path == null || getData.path == ""){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all blank fields");
                alert.showAndWait();

           }else{
               prepare = connect.prepareStatement(sql);
               prepare.setString(1, avallableCars_carId.getText());
               prepare.setString(2,avallableCars_brand.getText());
               prepare.setString(3,avallableCars_model.getText());
               prepare.setString(4,avallableCars_price.getText());
               prepare.setString(5,(String)avallableCars_status.getSelectionModel().getSelectedItem());
               
               String uri = getData.path;
               
               uri = uri.replace("\\", "\\\\");
                
               prepare.setString(6, uri);
               
               Date date = new Date();
               java.sql.Date sqlDate = new java.sql.Date(date.getTime());
               
               prepare.setString(7, String.valueOf(sqlDate));
               
               prepare.executeUpdate();
               
                alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("information Message");
                alert.setHeaderText(null);
                alert.setContentText("Successfully Added!");
                alert.showAndWait();
               
                avallableCarshowListData();
                avallableCarClear();
           }

          }catch(Exception e){e.printStackTrace();}
   
   }
   public void availableCarUpdate() {

        String uri = getData.path;
        uri = uri.replace("\\", "\\\\");

        String sql = "UPDATE car SET brand = '" + avallableCars_brand.getText() + "', model = '"
                + avallableCars_model.getText() + "', status ='"
                + avallableCars_status.getSelectionModel().getSelectedItem() + "', price = '"
                + avallableCars_price.getText() + "', image = '" + uri
                + "' WHERE car_id = '" + avallableCars_carId.getText() + "'";
   
            connect = database.connectDb();
            
             try {
            Alert alert;

            if (avallableCars_carId.getText().isEmpty()
                    || avallableCars_brand.getText().isEmpty()
                    || avallableCars_model.getText().isEmpty()
                    || avallableCars_status.getSelectionModel().getSelectedItem() == null
                    || avallableCars_price.getText().isEmpty()
                    || getData.path == null || getData.path == "") {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all blank fields");
                alert.showAndWait();
            } else {
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to UPDATE Car ID: " + avallableCars_carId.getText() + "?");
                Optional<ButtonType> option = alert.showAndWait();

                if (option.get().equals(ButtonType.OK)) {
                    statement = connect.createStatement();
                    statement.executeUpdate(sql);
                    
                alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("information Message");
                alert.setHeaderText(null);
                alert.setContentText("Successfully Updated!");
                alert.showAndWait();
                    
                    avallableCarshowListData();
                    avallableCarClear();

                  
                }

            }
        } catch (Exception e) {e.printStackTrace();}

   }
    
    public void availableCarDelete() {

        String sql = "DELETE FROM car WHERE car_id = '" + avallableCars_carId.getText() + "'";

        connect = database.connectDb();

        try {
            Alert alert;
            if (avallableCars_carId.getText().isEmpty()
                    || avallableCars_brand.getText().isEmpty()
                    || avallableCars_model.getText().isEmpty()
                    || avallableCars_status.getSelectionModel().getSelectedItem() == null
                    || avallableCars_price.getText().isEmpty()
                    || getData.path == null || getData.path == "") {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all blank fields");
                alert.showAndWait();
            } else {
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to DELETE Car ID: " + avallableCars_carId.getText() + "?");
                Optional<ButtonType> option = alert.showAndWait();

                if (option.get().equals(ButtonType.OK)) {
                    statement = connect.createStatement();
                    statement.executeUpdate(sql);

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Deleted!");
                    alert.showAndWait();

                    avallableCarshowListData();
                    avallableCarClear();
                }

            }
        } catch (Exception e) {e.printStackTrace();}
    }
   public void avallableCarClear() {
        avallableCars_carId.setText("");
        avallableCars_brand.setText("");
        avallableCars_model.setText("");
        avallableCars_status.getSelectionModel().clearSelection();
        avallableCars_price.setText("");
        
        getData.path = "";
        
        avallableCars_imageView.setImage(null);

   }
   private String[] listStatus =  {"Available","Not Availble"};
   public void avallableCarStatusList(){
       List<String>listS = new ArrayList<>();
       
       
       for(String data: listStatus){
           listS.add(data);
            
       
       }
       ObservableList listData = FXCollections.observableArrayList(listS);
            avallableCars_status.setItems(listData);
      
       
   
   
   }
   
   public void avallableCarImportImage(){
         
       FileChooser open = new FileChooser();
       open.setTitle("open Image File");
       open.getExtensionFilters().add(new ExtensionFilter("Image File", "*jpg", "*png"));
       
       File file = open.showOpenDialog(main_form.getScene().getWindow());
       
       if(file != null){
           
           getData.path = file.getAbsolutePath();
           
           image = new Image(file.toURI().toString(), 128, 151, false, true);
           avallableCars_imageView.setImage(image);
           
       }
   
   
   }
    
    public ObservableList<carData>avallableCarListData(){
        
        ObservableList<carData> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM car";
            connect = database.connectDb();
           
          try{
              prepare = connect.prepareStatement(sql);
              result = prepare.executeQuery();
              
              carData carD;
              while(result.next()){
                 carD = new carData(result.getInt("car_id")
                          , result.getString("brand")
                          , result.getString("model")
                          , result.getDouble("price")
                          , result.getString("status")
                          , result.getString("image")
                          , result.getDate("date"));
                    listData.add(carD);
                    
              
              
              }
          
          }catch(Exception e){e.printStackTrace();}  
          
            return listData;
        
    }
    
    private ObservableList<carData>avallableCarList;
    public void avallableCarshowListData(){
         avallableCarList = avallableCarListData(); 
         
         avallableCars_col_carId.setCellValueFactory(new PropertyValueFactory<>("carId"));
         avallableCars_col_brand.setCellValueFactory(new PropertyValueFactory<>("brand"));
         avallableCars_col_model.setCellValueFactory(new PropertyValueFactory<>("model"));
         avallableCars_col_price.setCellValueFactory(new PropertyValueFactory<>("price"));
         avallableCars_col_status.setCellValueFactory(new PropertyValueFactory<>("status"));

         avallableCars_tableView.setItems(avallableCarList);
    
    }
    public void avallableCarSearch() {

        FilteredList<carData> filter = new FilteredList<>(avallableCarList, e -> true);
    
        avallableCars_search.textProperty().addListener((Observable, oldValue, newValue) ->{
        
           filter.setPredicate(predicateCarData ->{
               
               
           if(newValue == null || newValue.isEmpty()){
                return true;           
           }
               String searchKey = newValue.toLowerCase();
               
               if(predicateCarData.getcarId().toString().contains(searchKey)){
                  return true;
               }else if(predicateCarData.getBrand().toLowerCase().contains(searchKey)){
                   return true;
               }else if(predicateCarData.getModel().toLowerCase().contains(searchKey)){
                  return true;  
               }else if((predicateCarData.getPrice() + "").contains(searchKey)){

                  return true;
               }else if(predicateCarData.getStatus().toLowerCase().contains(searchKey)){
                   return true;
               }else return false;
           
           });
        
        });
        
        SortedList<carData> sortList = new SortedList<>(filter);

        sortList.comparatorProperty().bind(avallableCars_tableView.comparatorProperty());
        avallableCars_tableView.setItems(sortList);
            
            
            
        }
            
        
                
     
    public void avallableCarSelect(){
        carData carD = avallableCars_tableView.getSelectionModel().getSelectedItem();
        int num = avallableCars_tableView.getSelectionModel().getSelectedIndex();
    
        if((num - 1) < - 1){return;}
        
        avallableCars_carId.setText(String.valueOf(carD.getcarId()));
        avallableCars_brand.setText(carD.getBrand());
        avallableCars_model.setText(carD.getModel());
        avallableCars_price.setText(String.valueOf(carD.getPrice()));
        
        
        getData.path = carD.getImage();
        
        String uri = "file:" + carD.getImage();
        
        
        image = new Image(uri, 128, 151, false, true);
        avallableCars_imageView.setImage(image);
        
    
    }
    
    
    public ObservableList<carData>rentCarListData(){
            
        ObservableList<carData>listData = FXCollections.observableArrayList();
        
           String sql = "SELECT * FROM car";
           
           connect = database.connectDb();
           
          try{
                  prepare = connect.prepareStatement(sql);
                  result = prepare.executeQuery();
                  
                  
                  carData carD;
                  while(result.next()){
                    
                      
                      carD = new carData(result.getInt("car_id"), result.getString("brand")
                              , result.getString("model"), result.getDouble("price")
                              , result.getString("status")
                              , result.getString("image")
                              , result.getDate("date"));
                      
                      listData.add(carD);
                  
                  }
           
              }catch(Exception e){e.printStackTrace();}
               return listData;
    }
    
    public void rentcarCarId(){
         
        String sql =   "SELECT car_id FROM car WHERE status = 'avallable'";
        connect = database.connectDb();
        try{
               prepare = connect.prepareStatement(sql);
               result  = prepare.executeQuery();
               ObservableList listData = FXCollections.observableArrayList();
               
               while (result.next()){
                   listData.add(result.getString("car_id"));
               
               }
               rent_carId.setItems(listData);
               
                       
                       
        }catch(Exception e){e. printStackTrace();}
                      
    
    
    
    }
    private ObservableList<carData>rentCarList;
    public void rentCarShowListdata(){
    
          rentCarList = rentCarListData();
          
          rent_col_carId.setCellValueFactory(new PropertyValueFactory<>("car_id"));
          rent_col_brand.setCellValueFactory(new PropertyValueFactory<>("brand"));
          rent_col_model.setCellValueFactory(new PropertyValueFactory<>("model"));
          rent_col_price.setCellValueFactory(new PropertyValueFactory<>("cprice"));
          rent_col_status.setCellValueFactory(new PropertyValueFactory<>("status"));
          
          
          rent_tableView.setItems(rentCarList);
    }
    
    public void displayUsername(){
    
        String user = getData.username;
        
        //TOSET THE FIRST LETTER TO BIG LETTER
        username.setText(user.substring(0, 1).toUpperCase() + user.substring(1));
        
        
    }
    
    private double x = 0;
    private double y = 0;
    
    
    public void logout(){
    
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Message");
        alert.setHeaderText(null);
        alert.setContentText("are you sure you wantto logout?");
        Optional<ButtonType>option = alert.showAndWait();
        
        try{
        if(option.get().equals(ButtonType.OK)){
            //HIED YOUR DASHBORD FORM
           logoutBtn.getScene().getWindow().hide();
           
             //LINK YOUR LOGIN FORM      
           Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
           
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        root.setOnMousePressed((MouseEvent event) ->{
            x =event.getSceneX();
            y =event.getSceneY();
       
        });
        
        root.setOnMouseDragged((MouseEvent event) ->{
            stage.setX(event.getScreenX() - x);
            stage.setY(event.getScreenX() - y);
            stage.setOpacity(.8);
        });
        root.setOnMouseReleased((MouseEvent event) ->{
            stage.setOpacity(1);
        });
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(scene);
            stage.show();
        
        }
        
        }catch(Exception e){e.printStackTrace();}
    }
    
    public void switchForm(ActionEvent event){
       
        if(event.getSource() == home_btn){
            home_form.setVisible(true);
            avallableCars_form.setVisible(false);
            rent_form.setVisible(false);
            
            home_btn.setStyle("-fx-background-color:linear-gradient(to bottom right , #686f86, #8e9296);");
            avallableCars_btn.setStyle("-fx-background-color:transparent");
            rentCar_btn.setStyle("-fx-background-color:transparent");
 
        }else if(event.getSource() == avallableCars_btn){
            home_form.setVisible(false);
            avallableCars_form.setVisible(true);
            rent_form.setVisible(false);
            
            avallableCars_btn.setStyle("-fx-background-color:linear-gradient(to bottom right , #686f86, #8e9296);");
            home_btn.setStyle("-fx-background-color:transparent");
            rentCar_btn.setStyle("-fx-background-color:transparent");
            //TO UPDATE YOURTABLEVIEW ONCE YOU CLICK THEAVALLABVLE THE BUTTON
            avallableCarshowListData();
            avallableCarStatusList();
            avallableCarSearch();
        }else if(event.getSource()== rentCar_btn){
            
            home_form.setVisible(false);
            avallableCars_form.setVisible(false);
            rent_form.setVisible(true);
            
            rentCar_btn.setStyle("-fx-background-color:linear-gradient(to bottom right , #686f86, #8e9296);");
            home_btn.setStyle("-fx-background-color:transparent");
            avallableCars_btn.setStyle("-fx-background-color:transparent");
            
            rentCarShowListdata();
            rentcarCarId();
        
        }
    }
    
   public void close(){
      System.exit(0);
}
   
   
   public void minimize(){
   
      Stage stage = (Stage)main_form.getScene().getWindow();
      stage.setIconified(true);
   }
   
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        displayUsername();
        
        
        //to display the data on the table view
        avallableCarshowListData();
        avallableCarStatusList();
        avallableCarSearch();
      
        
         rentCarShowListdata();
         rentcarCarId();
        
    }
    
}
